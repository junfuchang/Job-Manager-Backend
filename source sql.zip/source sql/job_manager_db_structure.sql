/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : job_manager_db

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 30/05/2023 09:17:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for amount
-- ----------------------------
DROP TABLE IF EXISTS `amount`;
CREATE TABLE `amount`  (
  `amount_id` int NOT NULL AUTO_INCREMENT COMMENT '账户ID',
  `role_id` int NOT NULL COMMENT '外键：角色ID',
  `username` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码（加密后）',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`amount_id`, `role_id`) USING BTREE,
  UNIQUE INDEX `user_id_UNIQUE`(`amount_id` ASC) USING BTREE,
  INDEX `fk_amount_role1_idx`(`role_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 299 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for college
-- ----------------------------
DROP TABLE IF EXISTS `college`;
CREATE TABLE `college`  (
  `college_id` int NOT NULL AUTO_INCREMENT COMMENT '学院ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '学院名称',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`college_id`) USING BTREE,
  UNIQUE INDEX `collage_id_UNIQUE`(`college_id` ASC) USING BTREE,
  UNIQUE INDEX `name_UNIQUE`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '学院表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for company
-- ----------------------------
DROP TABLE IF EXISTS `company`;
CREATE TABLE `company`  (
  `company_id` int NOT NULL AUTO_INCREMENT COMMENT '公司ID',
  `amount_id` int NOT NULL COMMENT '账户ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司名称',
  `code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '社会信用代码',
  `type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司类型',
  `contact` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司地址',
  `website` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司官网',
  `remark` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '备注',
  `pic` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '宣传图',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`company_id`, `amount_id`) USING BTREE,
  UNIQUE INDEX `company_id_UNIQUE`(`company_id` ASC) USING BTREE,
  INDEX `fk_company_user1_idx`(`amount_id` ASC) USING BTREE,
  CONSTRAINT `fk_company_user1` FOREIGN KEY (`amount_id`) REFERENCES `amount` (`amount_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '企业表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for job
-- ----------------------------
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job`  (
  `job_id` int NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `company_id` int NOT NULL COMMENT '外键：公司id',
  `title` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位名称',
  `intro` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位介绍',
  `claim` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '要求',
  `deadline` datetime NULL DEFAULT NULL COMMENT '截止时间',
  `contact` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '地址',
  `salary` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '薪资',
  `open_flag` int NULL DEFAULT 1 COMMENT '岗位是否开启',
  `type` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位类型',
  `create_time` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`job_id`, `company_id`) USING BTREE,
  UNIQUE INDEX `job_id_UNIQUE`(`job_id` ASC) USING BTREE,
  INDEX `fk_job_company1_idx`(`company_id` ASC) USING BTREE,
  CONSTRAINT `fk_job_company1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for job_student
-- ----------------------------
DROP TABLE IF EXISTS `job_student`;
CREATE TABLE `job_student`  (
  `job_student_id` int NOT NULL AUTO_INCREMENT COMMENT '岗位-简历表',
  `job_id` int NOT NULL COMMENT '外键：岗位ID',
  `student_id` int NOT NULL COMMENT '外键：学生ID',
  `date` datetime NULL DEFAULT NULL COMMENT '简历投递时间',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  `feedback` int NULL DEFAULT 0 COMMENT '企业收到简历的反馈\r\n0 = 未查看\r\n1 = 拒绝\r\n2 = 通过',
  PRIMARY KEY (`job_student_id`, `job_id`, `student_id`) USING BTREE,
  UNIQUE INDEX `job_resume_id_UNIQUE`(`job_student_id` ASC) USING BTREE,
  INDEX `fk_job_resume_job1_idx`(`job_id` ASC) USING BTREE,
  INDEX `fk_job_resume_resume1_idx`(`student_id` ASC) USING BTREE,
  CONSTRAINT `fk_job_student__resume1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_job_student_job1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '岗位-简历 关联表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for major
-- ----------------------------
DROP TABLE IF EXISTS `major`;
CREATE TABLE `major`  (
  `major_id` int NOT NULL AUTO_INCREMENT COMMENT '专业ID',
  `college_id` int NOT NULL COMMENT '外键：学院ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '专业名称',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`major_id`, `college_id`) USING BTREE,
  UNIQUE INDEX `major_id_UNIQUE`(`major_id` ASC) USING BTREE,
  INDEX `fk_major_collage1_idx`(`college_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '专业表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `menu_id` int NOT NULL AUTO_INCREMENT COMMENT '菜单id',
  `parent_id` int NULL DEFAULT 0 COMMENT '父菜单的id',
  `menu_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单名称',
  `menu_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单路由（子菜单的话需要包含父菜单路径）',
  `path_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单路由名称（用于配置路由名称）',
  `component_path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '前端组件',
  `menu_img_class` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单ICON',
  `menu_state` int NULL DEFAULT 0 COMMENT '是否启用菜单项(0 开启，1 关闭)',
  `is_contain_children` int NULL DEFAULT 0 COMMENT '是否包含子菜单',
  `menu_order` int NULL DEFAULT 0 COMMENT '菜单排序',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `role_id` int NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色名称',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`role_id`) USING BTREE,
  UNIQUE INDEX `role_id_UNIQUE`(`role_id` ASC) USING BTREE,
  UNIQUE INDEX `role_UNIQUE`(`role` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for role_menu
-- ----------------------------
DROP TABLE IF EXISTS `role_menu`;
CREATE TABLE `role_menu`  (
  `role_menu_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `menu_id` int NOT NULL,
  PRIMARY KEY (`role_menu_id`, `role_id`, `menu_id`) USING BTREE,
  INDEX `table_role_id_1`(`role_id` ASC) USING BTREE,
  INDEX `table_menu_id_2`(`menu_id` ASC) USING BTREE,
  CONSTRAINT `table_menu_id_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `table_role_id_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `student_id` int NOT NULL AUTO_INCREMENT COMMENT '学生学号ID',
  `amount_id` int NOT NULL COMMENT '账户ID',
  `major_id` int NOT NULL COMMENT '专业ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `resume` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '简历内容',
  `gender` int NULL DEFAULT NULL COMMENT '性别',
  `avatar` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '头像',
  `contact` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `address` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系地址',
  `birthday` datetime NULL DEFAULT NULL COMMENT '出生日期',
  `graduate_flag` int NULL DEFAULT 0 COMMENT '是否毕业：未毕业0，毕业1',
  `direction` int NULL DEFAULT NULL COMMENT '就业方向：升学0，就业1，待业2',
  `date` datetime NULL DEFAULT NULL COMMENT '毕业时间',
  `city` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '毕业城市',
  `degree` int NULL DEFAULT NULL COMMENT '学历：无0，学士1，硕士2，博士3',
  `salary` int NULL DEFAULT 0 COMMENT '薪资',
  `industry` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '行业',
  `post` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位',
  `remark` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '备注',
  `delete_flag` int NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`student_id`, `amount_id`, `major_id`) USING BTREE,
  INDEX `fk_user_info_user1_idx`(`amount_id` ASC) USING BTREE,
  INDEX `fk_user_info_major1_idx`(`major_id` ASC) USING BTREE,
  INDEX `student_id`(`student_id` ASC) USING BTREE,
  CONSTRAINT `fk_student_amount` FOREIGN KEY (`amount_id`) REFERENCES `amount` (`amount_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_student_major` FOREIGN KEY (`major_id`) REFERENCES `major` (`major_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1190204022 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

SET FOREIGN_KEY_CHECKS = 1;
