/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : job_manager_db

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 30/05/2023 09:17:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for amount
-- ----------------------------
DROP TABLE IF EXISTS `amount`;
CREATE TABLE `amount`  (
  `amount_id` int NOT NULL AUTO_INCREMENT COMMENT '账户ID',
  `role_id` int NOT NULL COMMENT '外键：角色ID',
  `username` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '密码（加密后）',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`amount_id`, `role_id`) USING BTREE,
  UNIQUE INDEX `user_id_UNIQUE`(`amount_id` ASC) USING BTREE,
  INDEX `fk_amount_role1_idx`(`role_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 299 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of amount
-- ----------------------------
INSERT INTO `amount` VALUES (1, 2, 'admin', '$2a$10$8Cs.VeWmE9DjVLmXdgsfMOaVCTmG2TGaWD4NNZHhkxTzmfHlclplO', 0, '2023-02-27 14:21:14', '2023-02-27 14:21:14');
INSERT INTO `amount` VALUES (256, 0, 'student', '$2a$10$WQHSD2JExWTLsnf9TPUoVuDRnlRIA7FNzBd9hxvWu7BRjVhS6rEdS', 1, '2023-03-07 20:26:34', '2023-03-07 20:26:34');
INSERT INTO `amount` VALUES (257, 1, 'company', '$2a$10$v0Ak8BgIfUMdNqiriGaTeeHo.WVA54dYOyXvnApDqkPudtDQFknue', 1, '2023-03-07 20:29:59', '2023-03-07 20:29:59');
INSERT INTO `amount` VALUES (274, 2, 'superadmin', '$2a$10$zzeoU2n7nxwkaSOWJJXp5uCDslOAJJqXic1ThhVD2/0fDyxxUgeMe', 1, '2023-05-03 15:15:11', '2023-05-03 15:15:11');
INSERT INTO `amount` VALUES (275, 0, 's00001', '$2a$10$LbKCSkfMJEMHaY/2ib8LmOJEWga6bnamS5S.Mb5I.uBiZOaack/Cm', 1, '2023-05-03 15:17:23', '2023-05-03 15:17:23');
INSERT INTO `amount` VALUES (276, 0, 'student0003', '$2a$10$J4EID/w4SCTrfbAd4HZpxOAbPDxxmRF08.qGQJq6TWhnyc2yjcAou', 1, '2023-05-03 15:42:23', '2023-05-03 15:42:23');
INSERT INTO `amount` VALUES (277, 0, 'student0004', '$2a$10$XwFh.wzghhLbd9HP2nBEwebizOTUe21tiVPPS0AFMBQ8mGcIaf2.O', 1, '2023-05-03 15:43:28', '2023-05-03 15:43:28');
INSERT INTO `amount` VALUES (278, 0, 'c-s-0001', '$2a$10$RAIPfXkXrs.j.6XI33etvecKZQGhZX0TfOnLTV./20F37eByfxDxW', 1, '2023-05-04 18:05:51', '2023-05-04 18:05:51');
INSERT INTO `amount` VALUES (279, 0, 'c-s-0002', '$2a$10$aa9OZyi2u59RAv1pHJaJ/OKgJRU/tHljVjnNsRJVd2APRs8cw90H6', 1, '2023-05-04 18:07:01', '2023-05-04 18:07:01');
INSERT INTO `amount` VALUES (280, 0, 'student', '$2a$10$jOb2fV3rwW3qLWkGmr8/3uVX/mSNkBBH5G.TQfa5wo0FYwy2sEiTK', 0, '2023-05-09 11:50:26', '2023-05-09 11:50:26');
INSERT INTO `amount` VALUES (281, 1, 'company', '$2a$10$Cz5R8CakgYf3pbk2afP0Z.qG2RDSBdRHds2AOZfZtzIWwnNh5wtXK', 0, '2023-05-09 13:20:22', '2023-05-09 13:20:22');
INSERT INTO `amount` VALUES (282, 0, 'student01', '$2a$10$byF.7EfQ5WKiYl7U31fLf.vPnNrDyav5ef3tEILvDH7k6oQ.EBkJO', 0, '2023-05-09 13:35:59', '2023-05-09 13:35:59');
INSERT INTO `amount` VALUES (283, 0, 'student02', '$2a$10$.SE6uBp1rFKN42wyQMkVqeY3bjUGoyRjakLp7zVY/MZnKKfUhaJ62', 0, '2023-05-09 14:16:02', '2023-05-09 14:16:02');
INSERT INTO `amount` VALUES (284, 0, 'student03', '$2a$10$PTxxyGRZKln/aNT9X8I/3u4CvbsYs8iYzSJnMHzORcYAUDTJ/xuva', 0, '2023-05-09 14:16:53', '2023-05-09 14:16:53');
INSERT INTO `amount` VALUES (285, 0, 'student04', '$2a$10$K55whn2Ijx6w0jXNNIIDKuls0hVuJs3sOMKymDFsQYR4B8wGJ.LZG', 0, '2023-05-09 14:17:49', '2023-05-09 14:17:49');
INSERT INTO `amount` VALUES (286, 0, 'student05', '$2a$10$1sj9sqqOza58QB/wRf3vWut83.wcGaSCuM.1HU5zRq4uLg3FuD5i6', 0, '2023-05-09 14:18:54', '2023-05-09 14:18:54');
INSERT INTO `amount` VALUES (287, 0, 'student06', '$2a$10$W4CnIx2qXAoRdahePmwnbu5P81ClyGHQLCgwFMo9CE0OP7X7cXvg2', 0, '2023-05-09 14:19:59', '2023-05-09 14:19:59');
INSERT INTO `amount` VALUES (288, 0, 'student07', '$2a$10$lBi2GPljmHnwe1v2kXEzhevY89JqAuopOxn.8KQiJqN6fMJdHbHuy', 0, '2023-05-09 14:21:16', '2023-05-09 14:21:16');
INSERT INTO `amount` VALUES (289, 0, 'student08', '$2a$10$PpO1exxZB0mUPmLL/Xa1POGedyZJyD3/CnHH5XiBy25MfehxWCNJ2', 0, '2023-05-09 14:21:56', '2023-05-09 14:21:56');
INSERT INTO `amount` VALUES (290, 0, 'student09', '$2a$10$Zj9gavU1Drb8/MW8LnTEiOvhFx7RX6EdWqLeBqFRXgay/EqtQL.Wy', 0, '2023-05-09 14:23:25', '2023-05-09 14:23:25');
INSERT INTO `amount` VALUES (291, 1, 'company01', '$2a$10$BMepAR5Y35Rev0KIcaEoGOHtJP5dLYj6Xa19IHMoHXOsySiWQ7/KW', 0, '2023-05-09 14:25:53', '2023-05-09 14:25:53');
INSERT INTO `amount` VALUES (292, 1, 'company02', '$2a$10$EEEiPxGR.mUzGMcKYePFNuv8YiWGqm5Enmv.E7G9DTcnz94ve9bSK', 0, '2023-05-09 14:26:54', '2023-05-09 14:26:54');
INSERT INTO `amount` VALUES (293, 1, 'comapny03', '$2a$10$Q5GGR5E4amK0wE06EdgbvO7KxezrgXp/wFJLGlTV3wgXFNyVOpqDW', 0, '2023-05-09 14:27:38', '2023-05-09 14:27:38');
INSERT INTO `amount` VALUES (294, 1, 'company04', '$2a$10$jFmlhKghxnSPU3aO8khS9.c8ZuY2nZ/e5bR757hbvuN0GS8zs8kXW', 0, '2023-05-09 14:28:52', '2023-05-09 14:28:52');
INSERT INTO `amount` VALUES (295, 0, 'student21', '$2a$10$/dklFIfCeN95ZDysERHWQufrz9hniGkNsIDBwxuFkKyGKC6vJrhpi', 0, '2023-05-24 23:23:02', '2023-05-24 23:23:02');
INSERT INTO `amount` VALUES (296, 0, 'student22', '$2a$10$Oro03HuP6bB7FRUT5q5GxOFQNArrQx668LQ0z/Qe3Mnl7Vo72rr4i', 0, '2023-05-24 23:31:53', '2023-05-24 23:31:53');
INSERT INTO `amount` VALUES (297, 1, 'company20', '$2a$10$/sXJyF1FYM4bXA6ITYLG2OUy3MWU105L4qDJMtu7vemNjVm/tB7Oi', 0, '2023-05-25 11:31:10', '2023-05-25 11:31:10');
INSERT INTO `amount` VALUES (298, 1, 'company22', '$2a$10$NF.CwNE5TrkXqOhaV.tW/u6ZFvoVkabErivWLL9pjecakLZWYopIe', 0, '2023-05-25 11:31:40', '2023-05-25 11:31:40');
INSERT INTO `amount` VALUES (299, 1, 'company23', '$2a$10$UoE0WgTU1tTpHckEBFwgj.9lvcN6xeX/GD8Mmy81XhIa2yOzrmGh2', 0, '2023-05-25 11:32:40', '2023-05-25 11:32:40');

-- ----------------------------
-- Table structure for college
-- ----------------------------
DROP TABLE IF EXISTS `college`;
CREATE TABLE `college`  (
  `college_id` int NOT NULL AUTO_INCREMENT COMMENT '学院ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '学院名称',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`college_id`) USING BTREE,
  UNIQUE INDEX `collage_id_UNIQUE`(`college_id` ASC) USING BTREE,
  UNIQUE INDEX `name_UNIQUE`(`name` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '学院表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of college
-- ----------------------------
INSERT INTO `college` VALUES (1, '信息与电子工程学院', 0);
INSERT INTO `college` VALUES (2, '自动化与电气工程学院', 0);
INSERT INTO `college` VALUES (3, '机械与能源工程学院', 0);
INSERT INTO `college` VALUES (4, '土木与建筑工程学院', 0);
INSERT INTO `college` VALUES (5, '生物与化学工程学院', 0);
INSERT INTO `college` VALUES (6, '环境与资源学院', 0);
INSERT INTO `college` VALUES (7, '艺术设计与服装学院', 0);
INSERT INTO `college` VALUES (8, '经济与管理学院', 0);
INSERT INTO `college` VALUES (9, '人文学院', 0);
INSERT INTO `college` VALUES (10, '理学院', 0);
INSERT INTO `college` VALUES (11, '外国语学院', 0);
INSERT INTO `college` VALUES (12, '中德学院', 0);
INSERT INTO `college` VALUES (13, '中德工程师学院', 0);
INSERT INTO `college` VALUES (14, '马克思主义学院', 0);
INSERT INTO `college` VALUES (15, '体育部', 0);
INSERT INTO `college` VALUES (16, '创新创业学院', 0);
INSERT INTO `college` VALUES (17, '继续教育学院', 0);
INSERT INTO `college` VALUES (18, '国际教育学院', 0);

-- ----------------------------
-- Table structure for company
-- ----------------------------
DROP TABLE IF EXISTS `company`;
CREATE TABLE `company`  (
  `company_id` int NOT NULL AUTO_INCREMENT COMMENT '公司ID',
  `amount_id` int NOT NULL COMMENT '账户ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司名称',
  `code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '社会信用代码',
  `type` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司类型',
  `contact` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司地址',
  `website` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '公司官网',
  `remark` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '备注',
  `pic` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '宣传图',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`company_id`, `amount_id`) USING BTREE,
  UNIQUE INDEX `company_id_UNIQUE`(`company_id` ASC) USING BTREE,
  INDEX `fk_company_user1_idx`(`amount_id` ASC) USING BTREE,
  CONSTRAINT `fk_company_user1` FOREIGN KEY (`amount_id`) REFERENCES `amount` (`amount_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '企业表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of company
-- ----------------------------
INSERT INTO `company` VALUES (4, 257, 'company', '1123123', '航天', '12345678923', 'address', 'http://s.f.com', 'mark237777', 'https://job-manager-junfuchang.oss-cn-hangzhou.aliyuncs.com/2023/3/1678192198571bg.png', 0);
INSERT INTO `company` VALUES (8, 281, '某某有限公司', '91350120MA2MAUBN2L', '建筑', '13612345678', '杭州市余杭区', 'http://www.xxxx.com', '一家建筑企业', 'https://job-manager-junfuchang.oss-cn-hangzhou.aliyuncs.com/2023\\5\\1683609621394home-icon.png', 0);
INSERT INTO `company` VALUES (9, 291, '瑞德医疗设备有限公司', '91110105314261509Y', '医疗器械', '13812345678', '北京市朝阳区', 'http://www.ruiyiliao.com', NULL, NULL, 0);
INSERT INTO `company` VALUES (10, 292, '星轮轮胎有限公司', '91320115552947335K', '轮胎制造', '13912345678', '江苏省无锡市', 'http://www.xingluntai.com', NULL, NULL, 0);
INSERT INTO `company` VALUES (11, 293, '德信房地产开发有限公司', '91350200577540475R', '房地产开发', '13712345678', '浙江省杭州市', 'http://www.dexinfang.com', NULL, NULL, 0);
INSERT INTO `company` VALUES (12, 294, '千禧互联科技有限公司', '91110108778754006P', '互联网技术服务', '13612345678', '北京市海淀区', 'http://www.qianxihulian.com', NULL, NULL, 0);
INSERT INTO `company` VALUES (13, 297, 'company20', 'company20', '医疗', '53242343333', '西湖区', NULL, NULL, NULL, 0);
INSERT INTO `company` VALUES (14, 298, 'company22', 'company22', 'company22', '32432412322', 'company22', NULL, NULL, NULL, 0);
INSERT INTO `company` VALUES (15, 299, 'company23', 'company23', 'company23', '43221212222', 'company23', NULL, NULL, NULL, 0);

-- ----------------------------
-- Table structure for job
-- ----------------------------
DROP TABLE IF EXISTS `job`;
CREATE TABLE `job`  (
  `job_id` int NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `company_id` int NOT NULL COMMENT '外键：公司id',
  `title` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位名称',
  `intro` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位介绍',
  `claim` varchar(1024) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '要求',
  `deadline` datetime NULL DEFAULT NULL COMMENT '截止时间',
  `contact` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '地址',
  `salary` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '薪资',
  `open_flag` int NULL DEFAULT 1 COMMENT '岗位是否开启',
  `type` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位类型',
  `create_time` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`job_id`, `company_id`) USING BTREE,
  UNIQUE INDEX `job_id_UNIQUE`(`job_id` ASC) USING BTREE,
  INDEX `fk_job_company1_idx`(`company_id` ASC) USING BTREE,
  CONSTRAINT `fk_job_company1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of job
-- ----------------------------
INSERT INTO `job` VALUES (8, 8, 'Java开发工程师', '1、负责并参与商家数据赋能平台的设计、研发及持续优化；\n2、深入理解广告变现，电商行业的数据逻辑，参与产品创新；\n3、参与解决海量商业数据分布式处理、高效查询、数据一致性、准确性等方面带来的各种技术难题和挑战。', '1、了解Java语言，以及Web应用前后端相关开发技术；\n2、专科及以上学历，计算机或相关专业毕业；\n3、了解Struts2、Spring、Hibernate等常用框架，了解css、Html和Ajax框架如: JQuery等；\n4、善于沟通，并对需求有良好的理解能力；\n5、诚实正直，工作积极主动，具备强烈的进取心、责任心、求知欲及团队合作精神。', '2023-05-09 08:00:00', '12312312322', '西湖区文一西路', '8k-12k', 1, '开发', NULL, 0);
INSERT INTO `job` VALUES (13, 8, 'JavaScript前端工程师', '1. 与产品经理、设计师、后端工程师配合完成需求开发及迭代；\n2. 对前端相关领域技术保持持续关注，用合理的技术方案解决问题；', '1. 计算机相关专业，本科及以上学历，毕业2年以上；\n2. 熟悉原生JS、ES6语法、HTTP协议、CSS样式、盒布局模型；\n3. 熟悉React或Vue，熟悉框架的基本思想和优化方法，了解组件化和模块化的开发方法；\n4. 沟通顺畅，具备对问题的一定抽象设计能力。\n5. 有完整上线的前端开发案例。', '2024-06-01 08:00:00', '12312312312', '杭州市余杭区', '15k-20k', 1, '开发', NULL, 0);

-- ----------------------------
-- Table structure for job_student
-- ----------------------------
DROP TABLE IF EXISTS `job_student`;
CREATE TABLE `job_student`  (
  `job_student_id` int NOT NULL AUTO_INCREMENT COMMENT '岗位-简历表',
  `job_id` int NOT NULL COMMENT '外键：岗位ID',
  `student_id` int NOT NULL COMMENT '外键：学生ID',
  `date` datetime NULL DEFAULT NULL COMMENT '简历投递时间',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  `feedback` int NULL DEFAULT 0 COMMENT '企业收到简历的反馈\r\n0 = 未查看\r\n1 = 拒绝\r\n2 = 通过',
  PRIMARY KEY (`job_student_id`, `job_id`, `student_id`) USING BTREE,
  UNIQUE INDEX `job_resume_id_UNIQUE`(`job_student_id` ASC) USING BTREE,
  INDEX `fk_job_resume_job1_idx`(`job_id` ASC) USING BTREE,
  INDEX `fk_job_resume_resume1_idx`(`student_id` ASC) USING BTREE,
  CONSTRAINT `fk_job_student__resume1` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_job_student_job1` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '岗位-简历 关联表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of job_student
-- ----------------------------
INSERT INTO `job_student` VALUES (13, 8, 1, '2023-04-19 15:20:14', 1, 0);
INSERT INTO `job_student` VALUES (14, 8, 1, '2023-04-19 15:20:22', 1, 0);
INSERT INTO `job_student` VALUES (15, 8, 1, '2023-04-19 15:20:23', 1, 0);
INSERT INTO `job_student` VALUES (16, 8, 1, '2023-04-19 15:20:31', 1, 0);
INSERT INTO `job_student` VALUES (17, 8, 1, '2023-04-19 15:20:41', 1, 1);
INSERT INTO `job_student` VALUES (18, 8, 1190204003, '2023-05-09 15:07:41', 1, 0);
INSERT INTO `job_student` VALUES (19, 8, 1190204004, '2023-05-09 15:37:08', 0, 2);
INSERT INTO `job_student` VALUES (20, 8, 1190000002, '2023-05-09 15:40:00', 0, 1);
INSERT INTO `job_student` VALUES (21, 8, 1190204003, '2023-05-09 16:48:13', 0, 2);
INSERT INTO `job_student` VALUES (22, 13, 1190204004, '2023-05-10 17:05:04', 0, 2);
INSERT INTO `job_student` VALUES (23, 13, 1190000001, '2023-05-25 15:07:01', 0, 2);

-- ----------------------------
-- Table structure for major
-- ----------------------------
DROP TABLE IF EXISTS `major`;
CREATE TABLE `major`  (
  `major_id` int NOT NULL AUTO_INCREMENT COMMENT '专业ID',
  `college_id` int NOT NULL COMMENT '外键：学院ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '专业名称',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`major_id`, `college_id`) USING BTREE,
  UNIQUE INDEX `major_id_UNIQUE`(`major_id` ASC) USING BTREE,
  INDEX `fk_major_collage1_idx`(`college_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci COMMENT = '专业表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of major
-- ----------------------------
INSERT INTO `major` VALUES (1, 1, '计算机科学与技术', 0);
INSERT INTO `major` VALUES (2, 2, '软件工程', 0);
INSERT INTO `major` VALUES (3, 1, '数字媒体与技术', 0);
INSERT INTO `major` VALUES (6, 1, '软件工程', 0);
INSERT INTO `major` VALUES (7, 1, '电子信息技术', 0);
INSERT INTO `major` VALUES (8, 4, '土木工程', 1);

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `menu_id` int NOT NULL AUTO_INCREMENT COMMENT '菜单id',
  `parent_id` int NULL DEFAULT 0 COMMENT '父菜单的id',
  `menu_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单名称',
  `menu_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单路由（子菜单的话需要包含父菜单路径）',
  `path_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单路由名称（用于配置路由名称）',
  `component_path` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '前端组件',
  `menu_img_class` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '菜单ICON',
  `menu_state` int NULL DEFAULT 0 COMMENT '是否启用菜单项(0 开启，1 关闭)',
  `is_contain_children` int NULL DEFAULT 0 COMMENT '是否包含子菜单',
  `menu_order` int NULL DEFAULT 0 COMMENT '菜单排序',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES (1, 0, '企业管理', 'company', '/home/company', 'company', 'TagsOutlined', 0, 0, 31);
INSERT INTO `menu` VALUES (2, 0, '总览', 'overview', '/home/overview', 'overview', 'AreaChartOutlined', 0, 0, 0);
INSERT INTO `menu` VALUES (4, 0, '编辑简历', 'resume', '/home/resume', 'resume', 'EditOutlined', 0, 0, 11);
INSERT INTO `menu` VALUES (5, 0, '账号管理', 'amount', '/home/amount', 'amount', 'ContactsOutlined', 0, 0, 33);
INSERT INTO `menu` VALUES (6, 0, '学生管理', 'student', '/home/student', 'student', 'TeamOutlined', 0, 0, 32);
INSERT INTO `menu` VALUES (7, 0, '发布岗位', 'job', '/home/job', 'job', 'PlusSquareOutlined', 0, 0, 21);
INSERT INTO `menu` VALUES (8, 0, '投递简历', 'submit-resume', '/home/submit-resume', 'submit-resume', 'SendOutlined', 0, 0, 12);
INSERT INTO `menu` VALUES (9, 0, '菜单管理', 'menu', '/home/menu', 'menu', 'MenuOutlined', 0, 0, 34);
INSERT INTO `menu` VALUES (10, 0, '学院管理', 'college', '/home/college', 'college', 'DeploymentUnitOutlined', 0, 0, 35);
INSERT INTO `menu` VALUES (11, 0, '修改信息', 'student-config', '/home/student-config', 'student-config', 'FormOutlined', 0, 0, 14);
INSERT INTO `menu` VALUES (12, 0, '修改信息', 'company-config', '/home/company-config', 'company-config', 'FormOutlined', 0, 0, 23);
INSERT INTO `menu` VALUES (13, 0, '投递记录', 'submit-resume-history', '/home/submit-resume-history', 'submit-resume-history', 'OrderedListOutlined', 0, 0, 13);
INSERT INTO `menu` VALUES (14, 0, '招聘列表', 'job-history', '/home/job-history', 'job-history', 'AlignLeftOutlined', 0, 0, 22);
INSERT INTO `menu` VALUES (15, 0, '岗位列表', 'job-list', '/home/job-list', 'job-list', 'UnorderedListOutlined', 0, 0, 20);
INSERT INTO `menu` VALUES (16, 0, '数据看板', 'overview-detail', '/home/overview-detail', 'overview-detail', 'BarChartOutlined', 0, 0, 1);

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `role_id` int NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色名称',
  `delete_flag` int NOT NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`role_id`) USING BTREE,
  UNIQUE INDEX `role_id_UNIQUE`(`role_id` ASC) USING BTREE,
  UNIQUE INDEX `role_UNIQUE`(`role` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, '企业', 0);
INSERT INTO `role` VALUES (2, '管理员', 0);
INSERT INTO `role` VALUES (6, '学生', 0);

-- ----------------------------
-- Table structure for role_menu
-- ----------------------------
DROP TABLE IF EXISTS `role_menu`;
CREATE TABLE `role_menu`  (
  `role_menu_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `menu_id` int NOT NULL,
  PRIMARY KEY (`role_menu_id`, `role_id`, `menu_id`) USING BTREE,
  INDEX `table_role_id_1`(`role_id` ASC) USING BTREE,
  INDEX `table_menu_id_2`(`menu_id` ASC) USING BTREE,
  CONSTRAINT `table_menu_id_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `table_role_id_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of role_menu
-- ----------------------------
INSERT INTO `role_menu` VALUES (35, 0, 2);
INSERT INTO `role_menu` VALUES (37, 0, 4);
INSERT INTO `role_menu` VALUES (42, 0, 8);
INSERT INTO `role_menu` VALUES (43, 0, 11);
INSERT INTO `role_menu` VALUES (45, 0, 13);
INSERT INTO `role_menu` VALUES (36, 1, 2);
INSERT INTO `role_menu` VALUES (40, 1, 7);
INSERT INTO `role_menu` VALUES (44, 1, 12);
INSERT INTO `role_menu` VALUES (46, 1, 14);
INSERT INTO `role_menu` VALUES (48, 1, 15);
INSERT INTO `role_menu` VALUES (50, 1, 16);
INSERT INTO `role_menu` VALUES (3, 2, 9);
INSERT INTO `role_menu` VALUES (5, 2, 2);
INSERT INTO `role_menu` VALUES (6, 2, 5);
INSERT INTO `role_menu` VALUES (32, 2, 1);
INSERT INTO `role_menu` VALUES (33, 2, 6);
INSERT INTO `role_menu` VALUES (41, 2, 10);
INSERT INTO `role_menu` VALUES (47, 2, 15);
INSERT INTO `role_menu` VALUES (49, 2, 16);

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `student_id` int NOT NULL AUTO_INCREMENT COMMENT '学生学号ID',
  `amount_id` int NOT NULL COMMENT '账户ID',
  `major_id` int NOT NULL COMMENT '专业ID',
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `resume` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL COMMENT '简历内容',
  `gender` int NULL DEFAULT NULL COMMENT '性别',
  `avatar` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '头像',
  `contact` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系方式',
  `address` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '联系地址',
  `birthday` datetime NULL DEFAULT NULL COMMENT '出生日期',
  `graduate_flag` int NULL DEFAULT 0 COMMENT '是否毕业：未毕业0，毕业1',
  `direction` int NULL DEFAULT NULL COMMENT '就业方向：升学0，就业1，待业2',
  `date` datetime NULL DEFAULT NULL COMMENT '毕业时间',
  `city` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '毕业城市',
  `degree` int NULL DEFAULT NULL COMMENT '学历：无0，学士1，硕士2，博士3',
  `salary` int NULL DEFAULT 0 COMMENT '薪资',
  `industry` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '行业',
  `post` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '岗位',
  `remark` varchar(512) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL COMMENT '备注',
  `delete_flag` int NULL DEFAULT 0 COMMENT '删除标识',
  PRIMARY KEY (`student_id`, `amount_id`, `major_id`) USING BTREE,
  INDEX `fk_user_info_user1_idx`(`amount_id` ASC) USING BTREE,
  INDEX `fk_user_info_major1_idx`(`major_id` ASC) USING BTREE,
  INDEX `student_id`(`student_id` ASC) USING BTREE,
  CONSTRAINT `fk_student_amount` FOREIGN KEY (`amount_id`) REFERENCES `amount` (`amount_id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_student_major` FOREIGN KEY (`major_id`) REFERENCES `major` (`major_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1190204022 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, 256, 2, 'student', '#  姓名\n**基本信息介绍**\n\n## 专业技能\n1. ...\n2. ...\n\n## 项目经历\n* ...\n* ...\n\n## 个人优势\n- ...\n- ...', 0, 'https://job-manager-junfuchang.oss-cn-c', '12345678900', 'address', '2023-03-01 08:00:00', 1, 0, '2023-03-21 08:00:00', '120000,120000,120101', 1, 230, '捡垃圾', '卖废品', '哇哈哈6666767', 1);
INSERT INTO `student` VALUES (2, 275, 1, 's00001', NULL, 1, NULL, '12123123122', NULL, NULL, 1, 0, '2023-05-24 08:00:00', '110000,110000,110101', 1, 0, NULL, NULL, NULL, 1);
INSERT INTO `student` VALUES (3, 276, 1, 'student0003', NULL, 0, 'https://job-manager-junfuchang.oss-cn-hangzhou.aliyuncs.com/2023\\5\\1683099741928浩瀚的地球风景4k高清壁纸_彼岸图网.jpg', '12312312322', '1231231', '2023-05-10 08:00:00', 1, 1, NULL, NULL, 1, 0, NULL, NULL, NULL, 1);
INSERT INTO `student` VALUES (4, 277, 1, 'student0003', NULL, 1, NULL, '21312312312', NULL, NULL, 1, 2, NULL, NULL, 2, 0, NULL, NULL, NULL, 1);
INSERT INTO `student` VALUES (190001, 278, 7, 'c-s-n-0001', NULL, 1, NULL, '11111111119', 'sadasd', '2023-05-03 08:00:00', 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 1);
INSERT INTO `student` VALUES (1190002, 279, 3, 'c-s-n-0002', NULL, 1, NULL, '23123123122', '撒大苏打', '2023-05-24 08:00:00', 1, 1, '2023-05-10 08:00:00', '330000,330100,330106', 1, 23423, '某某公司001', '开发', '备注消息', 1);
INSERT INTO `student` VALUES (1190000001, 280, 1, '张三', NULL, 1, NULL, '13812345678', '浙江省杭州市', '2000-01-01 08:00:00', 0, 0, NULL, '330000,330100,330122', 0, 0, NULL, NULL, '备注信息', 0);
INSERT INTO `student` VALUES (1190000002, 282, 2, '李四', '# Student01\n\n      学生1号\n      \n## 专业技能\n      1. ...\n      2. ...\n      \n## 项目经历\n      * ...\n      * ...\n      \n## 个人优势\n      - ...\n      - ...', 1, 'https://job-manager-junfuchang.oss-cn-hangzhou.aliyuncs.com/2023\\5\\1683610558510OIP-C.jpg', '13812345679', '浙江省宁波市', '2000-01-14 08:00:00', 1, 0, '2023-06-01 08:00:00', '330000,330100,330111', 1, 6000, '建筑', '测绘', NULL, 0);
INSERT INTO `student` VALUES (1190000006, 286, 6, '张敏', NULL, 1, NULL, '13712345679', '浙江省杭州市', NULL, 1, 1, '2023-06-22 08:00:00', '330000,330100,330108', 1, 9800, '互联网', '开发', NULL, 0);
INSERT INTO `student` VALUES (1190000007, 287, 3, '陈婷', NULL, 0, NULL, '13812345678', NULL, NULL, 1, 1, '2023-05-09 08:00:00', '330000,330100,330105', 0, 2000, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190000008, 288, 6, '王霞', NULL, 0, NULL, '13612345680', NULL, NULL, 1, 0, '2023-05-09 08:00:00', '330000,330100,330106', 2, 5000, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190000009, 289, 1, '李华', NULL, 1, NULL, '13912345681', NULL, NULL, 1, 1, '2023-05-18 08:00:00', '330000,330100,330106', 1, 13000, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190000010, 290, 1, '刘思思', NULL, 0, NULL, '13712345680', NULL, NULL, 1, 1, '2023-07-10 08:00:00', '330000,330100,330106', 2, 7000, '餐饮', '厨师', NULL, 0);
INSERT INTO `student` VALUES (1190204003, 283, 1, '王五', '# Student02\n > 基本信息介绍\n      \n## 专业技能\n1. ...\n2. ...\n      \n## 项目经历\n* ...\n* ...\n      \n## 个人优势\n- ...\n- ...', 1, NULL, '13712345678', '浙江省温州市', '1997-05-26 08:00:00', 1, 1, NULL, '330000,330100,330106', 1, 1500, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190204004, 284, 3, '王强', '# Student03\n > 我的名字叫小红\n      \n## 专业技能\n1. JavaScript\n2. Java\n      \n## 项目经历\n* 智慧社区项目\n  *   负责页面开发', 0, NULL, '13812345680', '浙江省温州市', '2001-04-18 08:00:00', 1, 1, NULL, '330000,330100,330106', 0, 5000, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190204005, 285, 3, '赵兰', NULL, 1, NULL, '13712345679', NULL, NULL, 1, 2, NULL, '330000,330100,330102', 2, 4000, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190204021, 295, 2, 'student21', '# 姓名\n >  Student21\n      \n## 专业技能\n1. ...\n2. ...\n      \n## 项目经历\n* ...\n* ...\n      \n## 个人优势\n- ...\n- ...', 1, NULL, '12323123222', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0);
INSERT INTO `student` VALUES (1190204022, 296, 3, 'student22', NULL, 0, 'https://job-manager-junfuchang.oss-cn-hangzhou.aliyuncs.com/2023\\5\\1684942312499咱们裸熊5k壁纸_彼岸图网.jpg', '12312312322', 'asdasddas', NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 0);

SET FOREIGN_KEY_CHECKS = 1;
